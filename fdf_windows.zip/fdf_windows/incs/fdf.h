/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   fdf.h                                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: marvin <marvin@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/06/23 14:15:27 by marvin            #+#    #+#             */
/*   Updated: 2023/06/23 14:15:27 by marvin           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef FDF_H

# define FDF_H

# define GLFW_DLL
# include <GL/glew.h>
# include <GLFW/glfw3.h>

# include <fcntl.h>
# include <stdio.h>
# include <math.h>

# include "libft.h"

# define HEX "0123456789abcdef"

# define ERR_OPEN "open"
# define ERR_MALLOC "malloc: failed to allocate memory\n"

# define RGB_RED(x) ((x >> 16) & 0xFF)
# define RGB_GREEN(x) ((x >> 8) & 0xFF)
# define RGB_BLUE(x) ((x >> 0) & 0xFF)

# define FDF_WINDOW_NAME "FdF"
# define FDF_WIDTH 800
# define FDF_HEIGHT 600
# define FDF_RGB_SIZE 3
# define FDF_MAGIC_COLOUR 255

# define SQRT_TWO sqrt(2)
# define SQRT_THREE sqrt(3)
# define SQRT_SIX sqrt(6)

typedef struct s_coord
{
	t_uint width;
	t_uint height;
}	t_coord;


typedef struct s_point
{
	int height;
	int colour;
}	t_point;

typedef struct s_pixinfo
{
	int		colour;
	int		x_pixel;
	int		y_pixel;
}	t_pixinfo;


typedef struct s_fdf
{
	GLFWwindow	*window;
	t_point		*map;
	t_uint		mrows;
	t_uint		mcols;
	t_pixinfo	*points;
	t_uint		win_width;
	t_uint		win_height;
	float		transf[3][3];
	float		pixelsize;
	float		x_off;
	float		y_off;
	t_uchar		*front_win;
	t_uchar		*back_win;
}	t_fdf;

int		error_msg(char *msg);

/*fdf_parsing.c*/
int		file_to_map(t_fdf *fdf, int fd);

/*fdf_parsing_utils.c*/

void 	drawstupidline(t_uchar *pixels, t_coord *start, t_coord *end);
int		getindex(int row, int col);

#endif
