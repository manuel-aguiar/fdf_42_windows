/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   fdf_xiaolinwu.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: marvin <marvin@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/07/18 13:22:41 by marvin            #+#    #+#             */
/*   Updated: 2023/07/18 13:22:41 by marvin           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "fdf.h"

void swap_pixels(t_pixel *start, t_pixel *end)
{
	t_pixel temp;

	temp = *start;
	*start = *end;
	*end = temp;
}

int	getindex(t_fdf *fdf, int row, int col)
{
	return (row * fdf->win_width * fdf->rgb_size + col * fdf->rgb_size);
}

void	set_pixel(t_fdf *fdf, int x, int y, int rgb)
{
	int index;

	index = getindex(fdf, y, x);
	fdf->front_win[index++] = (rgb >> 16) & 0xff;
	fdf->front_win[index++] = (rgb >> 8) & 0xff;
	fdf->front_win[index] = rgb & 0xff;
}

int		avg_colour(int start, int end, int num, int den)
{
	int r;
	int	g;
	int	b;

	r = ((start >> 16) & 0xff) * num / den \
		+ ((end >> 16) & 0xff) * (den - num) / den;
	g = ((start >> 8) & 0xff) * num / den \
		+ ((end >> 8) & 0xff) * (den - num) / den;
	b = (start & 0xff) *  num / den \
		+ (end & 0xff) * (den - num) / den;
	return (RGB(r, g, b));
}

int get_rgb(t_fdf *fdf, int x, int y)
{
	int index;
	int r;
	int g;
	int b;

	index = getindex(fdf, y, x);
	r = fdf->front_win[index++];
	g = fdf->front_win[index++];
	b = fdf->front_win[index];
	return (RGB(r, g, b));
}

int	xiaolin_x_major(t_fdf *fdf, t_pixel *start, t_pixel *end, t_xldata *data)
{
	data->err_adj = ((t_ulong)data->dy << 16) / (t_ulong)data->dx;
	data->save = data->dx;
	while (--data->dx)
	{
		data->err_temp = data->err_acc;
		data->err_acc += data->err_adj;
		if (data->err_acc <= data->err_temp)
			start->y++;
		start->x += data->slope;
		data->colour = avg_colour(start->colour, end->colour, data->dx, data->save);
		set_pixel(fdf, start->x, start->y, avg_colour(get_rgb(fdf, start->x,  \
		start->y), data->colour, data->err_acc, USHRT_MAX));
		set_pixel(fdf, start->x, start->y + 1, avg_colour(get_rgb(fdf, start->x, \
		start->y + 1), data->colour, USHRT_MAX - data->err_acc, USHRT_MAX));
	}
	set_pixel(fdf, end->x, end->y, end->colour);
	return (1);
}

int	xiaolin_y_major(t_fdf *fdf, t_pixel *start, t_pixel *end, t_xldata *data)
{
	data->err_adj = ((t_ulong)data->dx << 16) / (t_ulong)data->dy;
	data->save = data->dy;
	while (--data->dy)
	{
		data->err_temp = data->err_acc;
		data->err_acc += data->err_adj;
		if (data->err_acc <= data->err_temp)
			start->x += data->slope;
		start->y++;
		data->colour = avg_colour(start->colour, end->colour, data->dy, data->save);
		set_pixel(fdf, start->x, start->y, avg_colour(get_rgb(fdf, start->x, \
		start->y), data->colour, data->err_acc, USHRT_MAX));
		set_pixel(fdf, start->x + data->slope, start->y, avg_colour(get_rgb(fdf, \
		start->x + data->slope, start->y), data->colour, USHRT_MAX - data->err_acc, USHRT_MAX));
	}
	set_pixel(fdf, end->x, end->y, end->colour);
	return (1);
}

int	xiaolin_diagonal(t_fdf *fdf, t_pixel *start, t_pixel *end, t_xldata *data)
{
	data->save = data->dy;
	while (--data->dy != 0)
	{
		data->colour = avg_colour(start->colour, end->colour, data->dy, data->save);
		start->x += data->slope;
		start->y++;
		set_pixel(fdf, start->x, start->y, data->colour);
	}
	return (1);
}

int	xiaolin_horizontal(t_fdf *fdf, t_pixel *start, t_pixel *end, t_xldata *data)
{
	data->save = data->dy;
	while (--data->dy != 0)
	{
		data->colour = avg_colour(start->colour, end->colour, data->dy, data->save);
		start->y++;
		set_pixel(fdf, start->x, start->y, data->colour);
	}
	return (1);
}

int	xiaolin_vertical(t_fdf *fdf, t_pixel *start, t_pixel *end, t_xldata *data)
{
	data->save = data->dx;
	while (data->dx-- != 0)
	{
		data->colour = avg_colour(start->colour, end->colour, data->dx, data->save);
		start->x += data->slope;
		set_pixel(fdf, start->x, start->y, data->colour);
	}
	return (1);
}


int xiaolinwu_line(t_fdf *fdf, t_pixel start, t_pixel end)
{
	t_xldata	data;

	if (start.y > end.y)
		swap_pixels(&start, &end);
	set_pixel(fdf, start.x, start.y, start.colour);
	data.dx = end.x - start.x;
	if (data.dx >= 0)
		data.slope = 1;
	else
	{
		data.slope = -1;
		data.dx = -data.dx;
	}
	data.dy = end.y - start.y;
	if (data.dy == 0)
		return (xiaolin_vertical(fdf, &start, &end, &data));
	if (data.dx == 0)
		return (xiaolin_horizontal(fdf, &start, &end, &data));
	if (data.dx == data.dy)
		return (xiaolin_diagonal(fdf, &start, &end, &data));
	data.err_acc = 0;
	if (data.dy > data.dx)
		return (xiaolin_y_major(fdf, &start, &end, &data));
	return (xiaolin_x_major(fdf, &start, &end, &data));
}

