/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   fdf_xiaolinwu.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: marvin <marvin@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/07/18 11:16:18 by marvin            #+#    #+#             */
/*   Updated: 2023/07/18 11:16:18 by marvin           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "fdf.h"

int int_part(float x)
{
	return ((int)floorf(x));
}

float frac_part(float x)
{
	if (x > 0.f)
		return (x - (float)(int_part(x)));
	return (x - ((float)int_part(x) + 1.f));
}

void	ft_swap(int *a, int *b)
{
	int	temp;

	temp = *a;
	*a = *b;
	*b = temp;
}

void swap_pixels(t_pixel *start, t_pixel *end)
{
	t_pixel temp;

	temp = *start;
	*start = *end;
	*end = temp;
}

int get_rgb(t_fdf *fdf, int x, int y)
{
	int index;
	int r;
	int g;
	int b;

	index = getindex(y, x);
	r = fdf->front_win[index++];
	g = fdf->front_win[index++];
	b = fdf->front_win[index++];
	return (RGB(r, g, b));
}

int	xiaolin_x_major(t_fdf *fdf, t_pixel *start, t_pixel *end, t_xldata *line)
{
	/* It's an X-major line; calculate 16-bit fixed-point fractional part of a
		pixel that Y advances each time X advances 1 pixel, truncating the
		result to avoid overrunning the endpoint along the X axis */
	line->err_adj = ((unsigned long) line->dy << 16) / (unsigned long) line->dx;
	/* Draw all pixels other than the first and last */
	line->save = line->dx;
	while (--line->dx)
	{
		line->err_temp = line->err_acc;	/* remember current accumulated error */
		line->err_acc += line->err_adj;		/* calculate error for next pixel */
		if (line->err_acc <= line->err_temp) /* The error accumulator turned over, so advance the Y coord */
			start->y++;
		start->x += line->slope; /* X-major, so always advance X */
		line->colour = avg_colour(start->colour, end->colour, line->dx, line->save);
		set_pixel(fdf, start->x, start->y - 3, avg_colour(line->colour, get_rgb(fdf, start->x, start->y - 3), line->err_acc, USHRT_MAX));
		set_pixel(fdf, start->x, start->y - 2, line->colour);
		set_pixel(fdf, start->x, start->y - 1, line->colour);
		set_pixel(fdf, start->x, start->y, line->colour);
		set_pixel(fdf, start->x, start->y + 1, avg_colour(line->colour, get_rgb(fdf, start->x, start->y + 1), USHRT_MAX - line->err_acc, USHRT_MAX));
	}
	set_pixel(fdf, end->x, end->y, start->colour);
}

int	xiaolin_y_major(t_fdf *fdf, t_pixel *start, t_pixel *end, t_xldata *line)
{
	/* Y-major line; calculate 16-bit fixed-point fractional part of a
		pixel that X advances each time Y advances 1 pixel, truncating the
		result so that we won't overrun the endpoint along the X axis */
	line->err_adj = ((unsigned long) line->dx << 16) / (unsigned long) line->dy;
	/* Draw all pixels other than the first and last */
	line->save = line->dy;
	while (--line->dy)
	{
		line->err_temp = line->err_acc;	/* remember current accumulated error */
		line->err_acc += line->err_adj;		/* calculate error for next pixel */
		if (line->err_acc <= line->err_temp)   /* The error accumulator turned over, so advance the X coord */
			start->x += line->slope;
		start->y++; /* Y-major, so always advance Y */
		line->colour = avg_colour(start->colour, end->colour, line->dy, line->save);
		set_pixel(fdf, start->x - line->slope, start->y, avg_colour(line->colour, get_rgb(fdf, start->x - line->slope, start->y), line->err_acc, USHRT_MAX));
		set_pixel(fdf, start->x, start->y, line->colour);
		set_pixel(fdf, start->x + line->slope, start->y, avg_colour(line->colour, get_rgb(fdf, start->x + line->slope, start->y), USHRT_MAX - line->err_acc, USHRT_MAX));
	}
	set_pixel(fdf, end->x, end->y, start->colour);
}

int	xiaolin_diagonal(t_fdf *fdf, t_pixel *start, t_pixel *end, t_xldata *line)
{
	line->save = line->dy;
	while (--line->dy != 0)
	{
		line->colour = avg_colour(start->colour, end->colour, line->dy, line->save);
		start->x += line->slope;
		start->y++;
		set_pixel(fdf, start->x, start->y, line->colour);
	}
}

int	xiaolin_vertical(t_fdf *fdf, t_pixel *start, t_pixel *end, t_xldata *line)
{
	unsigned short thick_start;
	unsigned short i;

	thick_start = line->thickness / 2;
	line->dy += (thick_start * 2 + (line->thickness != 0 && line->thickness % 2));
	line->save = line->dy;
	start->y -= (thick_start + (line->thickness != 0));
	while (line->dy-- != 0)
	{
		line->colour = avg_colour(start->colour, end->colour, line->dy, line->save);
		start->y++;
		i = 0;
		//printf("start x %d start y %d\n", start->x, start->y);
		while (i < line->thickness)
			set_pixel(fdf, start->x - thick_start + i++, start->y, line->colour);
	}
	return (1);
}

int	xiaolin_horizontal(t_fdf *fdf, t_pixel *start, t_pixel *end, t_xldata *line)
{
	unsigned short thick_start;
	unsigned short i;

	thick_start = line->thickness / 2;
	line->dx += (thick_start * 2 + (line->thickness != 0 && line->thickness % 2));
	line->save = line->dx;
	start->x -= line->slope * (thick_start + (line->thickness != 0));
	while (line->dx-- != 0)
	{
		line->colour = avg_colour(start->colour, end->colour, line->dx, line->save);
		start->x += line->slope;
		i = 0;
		//printf("start x %d start y %d\n", start->x, start->y);
		while (i < line->thickness)
			set_pixel(fdf, start->x, start->y - thick_start + i++, line->colour);
	}
	return (1);
}


int xiaolinwu_line(t_fdf *fdf, t_pixel start, t_pixel end, unsigned short thickness)
{
	t_xldata	line;

	line.thickness = thickness;
	/* Make sure the line runs top to bottom */
	if (start.y > end.y)
		swap_pixels(&start, &end);
	set_pixel(fdf, start.x, start.y, end.colour);
	line.dx = end.x - start.x;
	if (line.dx >= 0)
		line.slope = 1;
	else
	{
		line.slope = -1;
		line.dx = -line.dx; /* make line.dx positive */
	}
	line.dy = end.y - start.y;
	if (line.dy == 0)
		return (xiaolin_horizontal(fdf, &start, &end, &line));
	if (line.dx == 0)
		return (xiaolin_vertical(fdf, &start, &end, &line));
	if (line.dx == line.dy)
		return (xiaolin_diagonal(fdf, &start, &end, &line));
	line.err_acc = 0;
	if (line.dy > line.dx)
		return (xiaolin_y_major(fdf, &start, &end, &line));
	return (xiaolin_x_major(fdf, &start, &end, &line));
}

