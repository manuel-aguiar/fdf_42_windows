/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   fdf_key_moves.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: marvin <marvin@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/07/20 16:49:32 by marvin            #+#    #+#             */
/*   Updated: 2023/07/20 16:49:32 by marvin           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "fdf.h"

int	adjust_offset(t_fdf *fdf, int *offset, int change)
{
	*offset += change;
	setup_points(fdf);
	return (1);
}

/*

int adjust_zoom(t_fdf *fdf, int change)
{

	fdf->view.zoom += change;
	if (fdf->view.zoom < 1)
		fdf->view.zoom = 1;
	setup_points(fdf);
	return (1);
}


*/

int adjust_zoom(t_fdf *fdf, int change)
{
	t_pixel	center;
	int		prev_zoom;

	prev_zoom = fdf->view.zoom;
	fdf->view.zoom += change;
	if (fdf->view.zoom < 1)
		fdf->view.zoom = 1;
	center = fdf->points[(fdf->mcols * (fdf->mrows / 2) + fdf->mcols / 2)];
	//printf("x off prev %d, ",fdf->view.x_offset);
	fdf->view.x_offset = fdf->win_width / 2 - (fdf->win_width / 2 - fdf->view.x_offset) * fdf->view.zoom / prev_zoom;
	//printf("x off new  %d, sub %d conta %d\n, ",fdf->view.x_offset, (fdf->win_width / 2 - fdf->view.x_offset), (fdf->win_width / 2 - fdf->view.x_offset) * fdf->view.zoom / prev_zoom);
	//printf("y off prev %d, ",fdf->view.y_offset);
	fdf->view.y_offset = fdf->win_height / 2 - (fdf->win_height / 2 - fdf->view.y_offset) * fdf->view.zoom / prev_zoom;
	//printf("y off new %d, \n",fdf->view.y_offset);
	setup_points(fdf);
	return (1);
}

int	apply_projection(t_fdf *fdf, int type)
{
	if (type == 1)
	{
		fdf->view.x_angle = 0;
		fdf->view.y_angle = 0;
		fdf->view.z_angle = 0;
	}
	else if(type == 2)
	{
		fdf->view.x_angle = X_ANGLE_START * (MY_PI / 180.0);
		fdf->view.y_angle = Y_ANGLE_START * (MY_PI / 180.0);
		fdf->view.z_angle = Z_ANGLE_START * (MY_PI / 180.0);
	}
	setup_view(fdf);
	setup_points(fdf);
	return (1);
}

int	change_height(t_fdf *fdf, float change)
{
	fdf->view.z_multi += change;
	if (fdf->view.z_multi < 0.01f)
		fdf->view.z_multi = 0.01f;
	setup_points(fdf);
	return (1);
}

int	key_rotate_x(t_fdf *fdf, float change)
{
	fdf->view.x_angle += change;
	fdf->view.cos_x = cosf(fdf->view.x_angle);
	fdf->view.sin_x = sinf(fdf->view.x_angle);
	setup_points(fdf);
	return (1);
}

int	key_rotate_y(t_fdf *fdf, float change)
{
	fdf->view.y_angle += change;
	fdf->view.cos_y = cosf(fdf->view.y_angle);
	fdf->view.sin_y = sinf(fdf->view.y_angle);
	setup_points(fdf);
	return (1);
}

int	key_rotate_z(t_fdf *fdf, float change)
{
	fdf->view.z_angle += change;
	fdf->view.cos_z = cosf(fdf->view.z_angle);
	fdf->view.sin_z = sinf(fdf->view.z_angle);
	setup_points(fdf);
	return (1);
}
