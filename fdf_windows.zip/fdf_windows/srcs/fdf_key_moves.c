/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   fdf_key_moves.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: marvin <marvin@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/07/20 16:49:32 by marvin            #+#    #+#             */
/*   Updated: 2023/07/20 16:49:32 by marvin           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "fdf.h"

int	adjust_offset(t_fdf *fdf, int *offset, int change)
{
	*offset += change;
	setup_view(fdf);
	setup_points(fdf);
	return (1);
}

int adjust_zoom(t_fdf *fdf, int change)
{

	fdf->view.zoom += change;
	if (fdf->view.zoom < 1)
		fdf->view.zoom = 1;
	fdf->view.center_x = (fdf->win_width / 2 - fdf->mcols * fdf->view.zoom / 2) + fdf->view.x_offset;
	fdf->view.center_y = (fdf->win_height / 2 - fdf->mrows * fdf->view.zoom / 2) + fdf->view.y_offset;
	setup_points(fdf);
	return (1);
}

int	apply_projection(t_fdf *fdf, int type)
{
	if (type == 1)
	{
		fdf->view.x_angle = 0;
		fdf->view.y_angle = 0;
		fdf->view.z_angle = 0;
	}
	else if(type == 2)
	{
		fdf->view.x_angle = X_ANGLE_START * (MY_PI / 180.0);
		fdf->view.y_angle = Y_ANGLE_START * (MY_PI / 180.0);
		fdf->view.z_angle = Z_ANGLE_START * (MY_PI / 180.0);
	}
	setup_view(fdf);
	setup_points(fdf);
	return (1);
}

int	change_height(t_fdf *fdf, float change)
{
	fdf->view.z_multi += change;
	if (fdf->view.z_multi < 0.01f)
		fdf->view.z_multi = 0.01f;
	setup_points(fdf);
	return (1);
}

int	key_rotate_angle(t_fdf *fdf, float *angle, float change)
{
	*angle += change;
	setup_view(fdf);
	setup_points(fdf);
	return (1);
}
