/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   fdf_bersenham.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: marvin <marvin@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/07/17 11:57:38 by marvin            #+#    #+#             */
/*   Updated: 2023/07/17 11:57:38 by marvin           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "fdf.h"



void bersenham_line(t_fdf *fdf, t_pixel start, t_pixel end)
{
    t_bhdata data;

	data.dx = ft_abs(end.x - start.x);
	data.dy = ft_abs(end.y - start.y);
    data.sx = ft_ternary((start.x < end.x), 1, -1);
    data.sy = ft_ternary((start.y < end.y), 1, -1);
    data.err = data.dx - data.dy;
    while (start.x != end.x || start.y != end.y)
	{
        set_pixel(fdf, start.x, start.y, avg_colour(start.colour, end.colour, \
		ft_abs(end.y - start.y), data.dy == 0 ? 1 : data.dy));
		data.err2 = 2 * data.err;
        if (data.err2 > -data.dy)
		{
            data.err -= data.dy;
            start.x += data.sx;
        }
        if (data.err2 < data.dx)
		{
            data.err += data.dx;
            start.y += data.sy;
        }
		//printf("start(%d, %d) end (%d, %d) same x ?%d, same y? %d\n", start.x, start.y, end.x, end.y, start.x == end.x, start.y == end.y);
    }
    set_pixel(fdf, start.x, start.y, avg_colour(start.colour, end.colour, \
	ft_abs(end.y - start.y), data.dy == 0 ? 1 : data.dy));
}
