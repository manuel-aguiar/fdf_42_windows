/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   fdf_setup.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: marvin <marvin@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/07/20 16:58:35 by marvin            #+#    #+#             */
/*   Updated: 2023/07/20 16:58:35 by marvin           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "fdf.h"

int	setup_view(t_fdf *fdf)
{
	fdf->view.cos_x = cosf(fdf->view.x_angle);
	fdf->view.sin_x = sinf(fdf->view.x_angle);
	fdf->view.cos_y = cosf(fdf->view.y_angle);
	fdf->view.sin_y = sinf(fdf->view.y_angle);
	fdf->view.cos_z = cosf(fdf->view.z_angle);
	fdf->view.sin_z = sinf(fdf->view.z_angle);
	return (1);
}

int setup_fdf(t_fdf *fdf, char *file)
{
	int			fd;

	fd = open(file, O_RDONLY);
	if (fd == -1)
		return (error_msg(ERR_OPEN));
	if (!file_to_map(fdf, fd))
		return (0);
	setup_default_vals(fdf);
	setup_view(fdf);
	fdf->points = malloc(sizeof((*fdf->points)) * fdf->lenmap);
	if (!fdf->points)
		return (error_msg(ERR_MALLOC));
	if (!setup_points(fdf))
	{
		free(fdf->map);
		return (0);
	}
	fdf->front_win = ft_calloc(fdf->win_width * fdf->win_height * fdf->rgb_size, sizeof(t_uchar));
	if (!fdf->front_win)
	{
		free(fdf->map);
		free(fdf->points);
		return (0);
	}
	return (1);
}


