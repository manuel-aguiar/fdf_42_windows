/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   fdf_setup.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: marvin <marvin@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/07/20 16:58:35 by marvin            #+#    #+#             */
/*   Updated: 2023/07/20 16:58:35 by marvin           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "fdf.h"


int points_to_window(t_fdf *fdf)
{
	int		i;
	t_pixel	new[2];

	i = 0;
	while (i < fdf->lenmap)
	{
		if (i + fdf->mcols < fdf->lenmap && liang_barsky_clipper \
			(fdf, fdf->points[i], fdf->points[i + fdf->mcols], new))
			xiaolinwu_line(fdf, new[0], new[1]);
		if (i / fdf->mcols == (i + 1) / fdf->mcols && liang_barsky_clipper \
			(fdf, fdf->points[i], fdf->points[i + 1], new))
			xiaolinwu_line(fdf, new[0], new[1]);
		i++;
	}
	return (1);
}

/*
void	transform_pixel(t_fdf *fdf, t_pixel *pixel)
{
	t_pixel	og;

	og = *pixel;
	pixel->x = (og.x * (fdf->view.cos_y * fdf->view.cos_z)) \
			+ (og.y * (fdf->view.sin_x * fdf->view.cos_y * fdf->view.cos_z - fdf->view.cos_x * fdf->view.sin_z)) \
			+ (og.z * (fdf->view.cos_x * fdf->view.cos_y));
	pixel->y = (og.x * (fdf->view.cos_y * fdf->view.sin_z)) \
			+ (og.y * (fdf->view.sin_x * fdf->view.sin_y * fdf->view.sin_z + fdf->view.cos_x * fdf->view.cos_z)) \
			+ (og.z * (fdf->view.cos_x * fdf->view.sin_y * fdf->view.sin_z - fdf->view.sin_x * fdf->view.cos_z));
	pixel->z = (og.x * (-fdf->view.sin_y)) \
			+ (og.y * (fdf->view.sin_x * fdf->view.cos_y)) \
			+ (og.z * (fdf->view.cos_x * fdf->view.cos_y));
}*/

void	transform_pixel(t_fdf *fdf, t_pixel *pixel)
{
	t_pixel	og;

	og = *pixel;
	pixel->y = og.y * fdf->view.cos_x + pixel->z * fdf->view.sin_x;
	pixel->z = og.y * -fdf->view.sin_x + pixel->z * fdf->view.cos_x;
	og = *pixel;
	pixel->x = og.x * fdf->view.cos_y + pixel->z * fdf->view.sin_y;
	pixel->z = og.x * -fdf->view.sin_y + pixel->z * fdf->view.cos_y;
	og = *pixel;
	pixel->x = og.x * fdf->view.cos_z - og.y * fdf->view.sin_z;
	pixel->y = og.x * fdf->view.sin_z + og.y * fdf->view.cos_z;
}

int	setup_points(t_fdf *fdf)
{
	int	i;


	i = 0;
	while (i < fdf->lenmap)
	{
		fdf->points[i].x = (i % fdf->mcols) * fdf->view.zoom;
		fdf->points[i].y = (fdf->mrows - (i / fdf->mcols + 1)) * fdf->view.zoom;
		fdf->points[i].z = fdf->map[i].height * fdf->view.zoom * fdf->view.z_multi;
		fdf->points[i].colour = fdf->map[i].colour;
		transform_pixel(fdf, &fdf->points[i]);
		fdf->points[i].x += fdf->view.center_x + fdf->view.x_offset;
		fdf->points[i].y += fdf->view.center_y + fdf->view.y_offset;
		i++;
	}
	return (1);
}

t_rgb	rgb_split(int colour)
{
	t_rgb	res;

	res.r = RGB_R(colour);
	res.g = RGB_G(colour);
	res.b = RGB_B(colour);
	return (res);
}

int default_colour(t_fdf *fdf, int min_rgb, int max_rgb)
{
	int		i;
	int		distmin;
	float	perc;
	t_rgb	res[3];

	res[1] = rgb_split(max_rgb);
	res[2] = rgb_split(min_rgb);
	fdf->z_range = fdf->max_z - fdf->min_z;
	i = 0;
	while (i < fdf->lenmap)
	{
		if (!fdf->map[i].colour)
		{
			perc = (float)(fdf->map[i].height - fdf->min_z) / (float)fdf->z_range;
			res[0].r = (t_uchar)(res[1].r * perc + res[2].r * (1 - perc));
			res[0].g = (t_uchar)(res[1].g * perc + res[2].g * (1 - perc));
			res[0].b = (t_uchar)(res[1].b * perc + res[2].b * (1 - perc));
			fdf->map[i].colour = RGB(res[0].r, res[0].g, res[0].b);
		}
		i++;
	}
	return (1);
}

int minmax_height(t_fdf *fdf)
{
	int	i;
	int	height;

	fdf->min_z = INT_MAX;
	fdf->max_z = INT_MIN;
	i = 0;
	while (i < fdf->lenmap)
	{
		height = fdf->map[i].height;
		if (height > fdf->max_z)
			fdf->max_z = height;
		if (height < fdf->min_z)
			fdf->min_z = height;
		i++;
	}
	fdf->z_range = fdf->max_z - fdf->min_z;
	default_colour(fdf, fdf->low_colour, fdf->high_colour);
	return (1);
}

int	setup_view(t_fdf *fdf)
{
	fdf->view.center_x = (fdf->win_width / 2 - fdf->mcols * fdf->view.zoom / 2) + fdf->view.x_offset;
	fdf->view.center_y = (fdf->win_height / 2 - fdf->mrows * fdf->view.zoom / 2) + fdf->view.y_offset;
	fdf->view.cos_x = cosf(fdf->view.x_angle);
	fdf->view.sin_x = sinf(fdf->view.x_angle);
	fdf->view.cos_y = cosf(fdf->view.y_angle);
	fdf->view.sin_y = sinf(fdf->view.y_angle);
	fdf->view.cos_z = cosf(fdf->view.z_angle);
	fdf->view.sin_z = sinf(fdf->view.z_angle);
	//printf("cos_x %.4f, sin_x %.4f, cos_y %.4f, sin_y %.4f, cos_z %.4f, sin_z %.4f\n", \
	 fdf->view.cos_x, fdf->view.sin_x, fdf->view.cos_y, fdf->view.sin_y, fdf->view.cos_z, fdf->view.sin_z);
	return (1);
}

void	setup_default_vals(t_fdf *fdf)
{
	fdf->win_width = FDF_WIDTH;
	fdf->win_height = FDF_HEIGHT;
	ft_strlcpy(fdf->win_name, FDF_WINDOW_NAME, sizeof(fdf->win_name));
	fdf->rgb_size = FDF_RGB_SIZE;
	fdf->view.x_angle = X_ANGLE_START * (MY_PI / 180.0);
	fdf->view.y_angle = Y_ANGLE_START * (MY_PI / 180.0);
	fdf->view.z_angle = Z_ANGLE_START * (MY_PI / 180.0);
	fdf->low_colour = LOW_RGB;
	fdf->high_colour = HIGH_RGB;
	fdf->view.zoom = ft_min(fdf->win_width / fdf->mcols / 2, fdf->win_height / fdf->mrows / 2);
	fdf->view.x_offset = 0;
	fdf->view.y_offset = 0;
	fdf->view.z_multi = 1;
}

int setup_map(t_fdf *fdf, char *file)
{
	int			fd;

	fd = open(file, O_RDONLY);
	if (fd == -1)
		return (error_msg(ERR_OPEN));
	if (!file_to_map(fdf, fd))
		return (0);
	setup_default_vals(fdf);
	minmax_height(fdf);
	setup_view(fdf);
	fdf->points = malloc(sizeof((*fdf->points)) * fdf->lenmap);
	if (!fdf->points)
		return (error_msg(ERR_MALLOC));
	if (!setup_points(fdf))
	{
		free(fdf->map);
		return (0);
	}
	fdf->front_win = ft_calloc(fdf->win_width * fdf->win_height * fdf->rgb_size, sizeof(t_uchar));
	if (!fdf->front_win)
	{
		free(fdf->map);
		free(fdf->points);
		return (0);
	}
	return (1);
}

int		init_fdf(t_fdf *fdf, char *file)
{
	if (!setup_map(fdf, file))
		return (0);
}


