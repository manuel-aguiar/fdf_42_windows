/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   fdf_windows.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: marvin <marvin@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/07/20 16:55:36 by marvin            #+#    #+#             */
/*   Updated: 2023/07/20 16:55:36 by marvin           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "fdf.h"

void	keyCallback(GLFWwindow* window, int key, int scancode, int action, int mods)
{
	(void)scancode;
	(void)mods;
    if (key == GLFW_KEY_ESCAPE && action == GLFW_PRESS)
        glfwSetWindowShouldClose(window, GL_TRUE);
}

int		init_window(t_fdf *fdf)
{
	if (!glfwInit())
        return (0);
	fdf->window = glfwCreateWindow(fdf->win_width, fdf->win_height, fdf->win_name, NULL, NULL);
	if (!fdf->window)
	{
		glfwTerminate();
		return (0);
	}
	glfwMakeContextCurrent(fdf->window);
	if (glewInit() != GLEW_OK)
	{
		glfwTerminate();
		return (0);
	}
	return (1);
}

int		new_render(t_fdf *fdf, void (*keycallback)())
{
	glfwSetKeyCallback(fdf->window, keycallback);
	glViewport(0, 0, (*fdf).win_width, (*fdf).win_height);
    while (!glfwWindowShouldClose(fdf->window)) {


		glRasterPos2f(-1, -1);
		ft_memset(fdf->front_win, 0, fdf->win_width * fdf->win_height * fdf->rgb_size * sizeof(*(fdf->front_win)));

		points_to_window(fdf);

		/*
		t_pixel start1 = {255, 943, 426, 300};
		t_pixel end1 = {255 << 16, 823, 341, 300};
		bersenham_line(fdf, start1, end1);

		printf("(x,y,z) =(%.3f,%.3f,%.3f) = (%.3f,%.3f,%.3f)\n", fdf->view.x_angle, fdf->view.y_angle, fdf->view.z_angle,
		fdf->view.x_angle * 180 / MY_PI, fdf->view.y_angle * 180 / MY_PI, fdf->view.z_angle * 180 / MY_PI);

		printf("zoom %d\n", fdf->view.zoom);*/

		glClear(GL_COLOR_BUFFER_BIT);
        glDrawPixels(fdf->win_width, fdf->win_height, GL_RGB, GL_UNSIGNED_BYTE, fdf->front_win);

		glfwSwapBuffers(fdf->window);
        glfwPollEvents();
		if (glfwGetKey(fdf->window, GLFW_KEY_UP))
        	adjust_offset(fdf, &fdf->view.y_offset, 1 + (int)(fdf->mcols / 100));
		if (glfwGetKey(fdf->window, GLFW_KEY_DOWN))
        	adjust_offset(fdf, &fdf->view.y_offset, -1 - (int)(fdf->mcols / 100));
		if (glfwGetKey(fdf->window, GLFW_KEY_RIGHT))
        	adjust_offset(fdf, &fdf->view.x_offset, 1 + (int)(fdf->mcols / 100));
		if (glfwGetKey(fdf->window, GLFW_KEY_LEFT))
        	adjust_offset(fdf, &fdf->view.x_offset, -1 - (int)(fdf->mcols / 100));
		if (glfwGetKey(fdf->window, GLFW_KEY_O))
        	adjust_zoom(fdf, 1);
		if (glfwGetKey(fdf->window, GLFW_KEY_P))
        	adjust_zoom(fdf, -1);
		if (glfwGetKey(fdf->window, GLFW_KEY_S))
        	key_rotate_x(fdf, 0.005f);
		if (glfwGetKey(fdf->window, GLFW_KEY_W))
        	key_rotate_x(fdf, -0.005f);
		if (glfwGetKey(fdf->window, GLFW_KEY_A))
        	key_rotate_y(fdf, 0.005f);
		if (glfwGetKey(fdf->window, GLFW_KEY_D))
        	key_rotate_y(fdf, -0.005f);
		if (glfwGetKey(fdf->window, GLFW_KEY_Q))
        	key_rotate_z(fdf, 0.005f);
		if (glfwGetKey(fdf->window, GLFW_KEY_E))
        	key_rotate_z(fdf, -0.005f);
		if (glfwGetKey(fdf->window, GLFW_KEY_B))
        	apply_projection(fdf, 1);
		if (glfwGetKey(fdf->window, GLFW_KEY_N))
        	apply_projection(fdf, 2);
		if (glfwGetKey(fdf->window, GLFW_KEY_M))
        	apply_projection(fdf, 3);
		if (glfwGetKey(fdf->window, GLFW_KEY_I))
        	apply_projection(fdf, 2);
		if (glfwGetKey(fdf->window, GLFW_KEY_H))
        	change_height(fdf, 0.01f);
		if (glfwGetKey(fdf->window, GLFW_KEY_L))
        	change_height(fdf, -0.01f);
    }
	return (1);
}
