/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   fdf_main.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: marvin <marvin@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/07/11 09:56:31 by marvin            #+#    #+#             */
/*   Updated: 2023/07/11 09:56:31 by marvin           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "fdf.h"

void	print_height(t_fdf *fdf)
{
	int i;
	int total;

	total = (*fdf).mrows * (*fdf).mcols;
	i = 0;
	while (i < total)
	{
		if (!(i % (*fdf).mcols) && i != 0)
			printf("\n");
		printf("%4d", fdf->map[i].height);
		i++;
	}
}

int 	iso_matrix(t_fdf *fdf)
{
	fdf->transf[0][0] = SQRT_TWO / 2;
	fdf->transf[0][1] = - (SQRT_TWO / 2);
	fdf->transf[0][2] = 0;
	fdf->transf[1][0] = 1 / SQRT_SIX;
	fdf->transf[1][1] = 1 / SQRT_SIX;
	fdf->transf[1][2] = -2 / SQRT_SIX;
	fdf->transf[2][0] = 1 / SQRT_THREE;
	fdf->transf[2][1] = 1 / SQRT_THREE;
	fdf->transf[2][2] = 1 / SQRT_THREE;
	return (1);
}

int	setup_points(t_fdf *fdf)
{
	fdf->points = malloc(sizeof((*fdf->points)) * (*fdf).mcols * (*fdf).mrows);
	if (!fdf->points)
		return (0);
}

int apply_transf(t_fdf *fdf)
{
	int		total;
	int		i;
	float	x_trf;
	float	y_trf;

	total = (*fdf).mrows * (*fdf).mcols;
	i = 0;
	while (i < total)
	{
		//printf("x %d, y %d, z %d\n", (i % (*fdf).mcols), (i / (*fdf).mrows), (*fdf).map[i].height);
		x_trf = (*fdf).transf[0][0] * (i % (*fdf).mcols) + (*fdf).transf[0][1] * (i / (*fdf).mcols) + (*fdf).transf[0][2] * (*fdf).map[i].height;
		y_trf = (*fdf).transf[1][0] * (i % (*fdf).mcols) + (*fdf).transf[1][1] * (i / (*fdf).mcols) + (*fdf).transf[1][2] * (*fdf).map[i].height;
		fdf->points[i].x_pixel = (int)((x_trf + 1.0f) * 0.5f * (*fdf).pixelsize + (*fdf).x_off);
		fdf->points[i].y_pixel = (int)((y_trf + 1.0f) * 0.5f * (*fdf).pixelsize + (*fdf).y_off);
		fdf->points[i].colour = (*fdf).map[i].colour;
		if (fdf->points[i].colour == 0)
			fdf->points[i].colour = FDF_MAGIC_COLOUR;
		printf("x %d, y %d, z %d becomes pixel x %d, y %d\n", (i % (*fdf).mcols), (i / (*fdf).mcols), (*fdf).map[i].height, fdf->points[i].x_pixel, fdf->points[i].y_pixel);
		i++;
	}
}

int setup_map(t_fdf *fdf, char *file)
{
	int			fd;

	fd = open(file, O_RDONLY);
	if (fd == -1)
		return (error_msg(ERR_OPEN));
	if (!file_to_map(fdf, fd))
		return (0);
	iso_matrix(fdf);
	(*fdf).win_width = FDF_WIDTH;
	(*fdf).win_height = FDF_HEIGHT;
	(*fdf).pixelsize = fminf((*fdf).win_width, (*fdf).win_height) / 2.0f;
	(*fdf).x_off = ((*fdf).win_width - (*fdf).pixelsize) / 2.0f;
	(*fdf).y_off = ((*fdf).win_height - (*fdf).pixelsize) / 2.0f;
	if (!setup_points(fdf))
	{
		free(fdf->map);
		return (0);
	}
	fdf->front_win = ft_calloc((*fdf).win_width * (*fdf).win_height * FDF_RGB_SIZE, sizeof(t_uchar));
	if (!fdf->front_win)
	{
		free(fdf->map);
		free(fdf->points);
		return (0);
	}
	return (1);
}


void	keyCallback(GLFWwindow* window, int key, int scancode, int action, int mods) {
    if (key == GLFW_KEY_ESCAPE && action == GLFW_PRESS) {
        glfwSetWindowShouldClose(window, GL_TRUE);
    }
}

int		init_window(t_fdf *fdf, char *file)
{
	if (!glfwInit())
        return (0);
	fdf->window = glfwCreateWindow(FDF_WIDTH, FDF_HEIGHT, FDF_WINDOW_NAME, NULL, NULL);
	if (!fdf->window)
	{
		glfwTerminate();
		return (0);
	}
	glfwMakeContextCurrent(fdf->window);
	if (glewInit() != GLEW_OK)
	{
		glfwTerminate();
		return (0);
	}
	return (1);
}

int		dump_pixels(t_fdf *fdf)
{
	int		total;
	int		i;

	total = (*fdf).mrows * (*fdf).mcols;
	i = 0;
	while (i < total)
	{
		printf("x pixel %d, y pixel %d, index %d\n", fdf->points[i].x_pixel, fdf->points[i].y_pixel, (*fdf).win_width * fdf->points[i].y_pixel + fdf->points[i].x_pixel);
		fdf->front_win[(*fdf).win_width * fdf->points[i].y_pixel + fdf->points[i].x_pixel] = FDF_MAGIC_COLOUR;
		i++;
	}
}

int		ft_ternary(int cond, int true, int false)
{
	if (cond)
		return (true);
	return (false);
}

int		ft_abs(int num)
{
	return (ft_ternary(num > 0, num, -num));
}

void bersenham_line(t_fdf *fdf, int x0, int y0, int x1, int y1)
{
    int dx;
    int dy;
    int sx;
    int sy;
    int err;

	dx = ft_abs(x1 - x0);
	dy = ft_abs(y1 - y0);
    sx = ft_ternary((x0 < x1), 1, -1);
    sy = ft_ternary((y0 < y1), 1, -1);
    err = dx - dy;
    while (x0 != x1 || y0 != y1)
	{
        fdf->front_win[getindex(y0, x0)] = FDF_MAGIC_COLOUR;
        if (2 * err > -dy)
		{
            err -= dy;
            x0 += sx;
        }
        if (2 * err < dx)
		{
            err += dx;
            y0 += sy;
        }
    }
    fdf->front_win[getindex(y0, x0)] = FDF_MAGIC_COLOUR;
}

int		new_render(t_fdf *fdf, void (*keycallback)())
{
	glfwSetKeyCallback(fdf->window, keycallback);
	glViewport(0, 0, (*fdf).win_width, (*fdf).win_height);

    while (!glfwWindowShouldClose(fdf->window)) {


		glRasterPos2f(-1, -1);
		ft_memset(fdf->front_win, 0, FDF_WIDTH * FDF_HEIGHT * FDF_RGB_SIZE * sizeof(t_uchar));
		bersenham_line(fdf, 200, 300, 400, 550);
		bersenham_line(fdf, 500, 400, 300, 500);
		glClear(GL_COLOR_BUFFER_BIT);
        glDrawPixels(FDF_WIDTH, FDF_HEIGHT, GL_RGB, GL_UNSIGNED_BYTE, fdf->front_win);

		glfwSwapBuffers(fdf->window);
        glfwPollEvents();

    }
	free(fdf->front_win);
	glfwDestroyWindow(fdf->window);
    glfwTerminate();
}

int		basic_render(t_fdf *fdf, void (*keycallback)())
{
	t_uchar *pixels_1;
	t_uchar *pixels_2;

	t_coord start = {200, 200};
	t_coord end_1 = {400, 200};
	t_coord end_2 = {200, 400};

	pixels_1 = ft_calloc(FDF_WIDTH * FDF_HEIGHT * FDF_RGB_SIZE, sizeof(t_uchar));
	pixels_2 = ft_calloc(FDF_WIDTH * FDF_HEIGHT * FDF_RGB_SIZE, sizeof(t_uchar));
	if (!pixels_1 || !pixels_2)
	{
		glfwTerminate();
		exit(1);
	}

	glfwSetKeyCallback(fdf->window, keycallback);

	glViewport(0, 0, FDF_WIDTH, FDF_HEIGHT);

    while (!glfwWindowShouldClose(fdf->window)) {


		glRasterPos2f(-1, -1);
		ft_memset(pixels_2, 0, FDF_WIDTH * FDF_HEIGHT * FDF_RGB_SIZE * sizeof(t_uchar));
		drawstupidline(pixels_2, &start, &end_2);
		glClear(GL_COLOR_BUFFER_BIT);
        glDrawPixels(FDF_WIDTH, FDF_HEIGHT, GL_RGB, GL_UNSIGNED_BYTE, pixels_2);

		glfwSwapBuffers(fdf->window);
        glfwPollEvents();

        glRasterPos2f(-1, -1);
		ft_memset(pixels_1, 0, FDF_WIDTH * FDF_HEIGHT * FDF_RGB_SIZE * sizeof(t_uchar));
		drawstupidline(pixels_1, &start, &end_1);
		glClear(GL_COLOR_BUFFER_BIT);
        glDrawPixels(FDF_WIDTH, FDF_HEIGHT, GL_RGB, GL_UNSIGNED_BYTE, pixels_1);

        glfwSwapBuffers(fdf->window);
        glfwPollEvents();
    }
	free(pixels_1);
	free(pixels_2);
	glfwDestroyWindow(fdf->window);
    glfwTerminate();
}

int		init_fdf(t_fdf *fdf, char *file)
{
	if (!setup_map(fdf, file))
		return (0);
}

int main(int ac, char **av)
{
	t_fdf	fdf;

	if (ac != 2)
		return (0);
	if (!init_fdf(&fdf, av[1]))
		return (0);
	//apply_transf(&fdf);
	//dump_pixels(&fdf);
	if (!init_window(&fdf, av[1]))
		return (0);
	//printf("width %d, height %d", fdf.win_width, fdf.win_height);
	new_render(&fdf, &keyCallback);

	//print_height(&fdf);
    return (0);
}
