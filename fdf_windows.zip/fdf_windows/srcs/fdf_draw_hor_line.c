/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   draw_hor_line.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: marvin <marvin@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/06/23 14:40:40 by marvin            #+#    #+#             */
/*   Updated: 2023/06/23 14:40:40 by marvin           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "fdf.h"

int	getindex(int row, int col)
{
	return (row * FDF_WIDTH * FDF_RGB_SIZE + col * FDF_RGB_SIZE);
}


void 	drawstupidline(t_uchar *pixels, t_coord *start, t_coord *end)
{
	int i;
	int j;
	int index;

	j = start->height;
	while (j <= end->height)
	{
		i = start->width;
		while (i <= end->width)
		{
			index = getindex(j, i);
			pixels[index] = FDF_MAGIC_COLOUR;
			i++;
		}
		j++;
	}
}
